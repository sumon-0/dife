
<?php $__env->startSection('content'); ?>
    <div class="pt-table">
        <div class="pt-tablecell relative">
            <!-- .close -->
            <a href="/" class="page-close"><i class="tf-ion-close"></i></a>
            <!-- /.close -->

            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-md-offset-1 col-md-10 col-lg-offset-2 col-lg-8">

                            <style>
                                .accordion1{
                                    background-color:green;
                                    font-size: 25px;
                                    margin-bottom: 20px;
                                    color: white;

                                }

                                .accordion2{
                                    background-color: red;
                                    font-size: 25px;
                                    margin-bottom: 20px;
                                    color: white;
                                }
                            </style>

                        <div id="acc-border">
                            <h2 class="question"><?php echo $questions[0]->question; ?> </h2>
                            <div id="acc1">
                                <details>
                                    <summary class="accordion1">হ্যাঁ, তাহলে কি ঝুকিমুক্ত?</summary>
                                    <p>আপনার কারখানাটি ঝুকিমুক্ত রয়েছে। আপনাকে নিম্নোক্ত বিষয়গুলো পর্যবেক্ষণে রাখতে হবে-<br>
                                        ১. ফায়ার হাইড্রেন্ট সিস্টেমটি BNBC 2006, BNBC 2020 এবং NFPA 14 স্ট্যান্ডার্ড অনুযায়ী করা হয়েছে কি
                                        না;<br>
                                        ২. ফায়ার পাম্প সার্বক্ষণিক চালু আছে কি না;<br>
                                        ৩. ফায়ার হাইড্রেন্ট সিস্টেমের কোন পাইপে লিকেজ আছে কি না।<br>
                                    </p>

                                </details>
                            </div>

                            <div id="acc2">
                                <details>
                                    <summary class="accordion2">না, তাহলে করনীয় কি?</summary>
                                    <p>আপনার কারখানাটি ঝুকির মধ্যে রয়েছে। দ্রুততম সময়ের মাঝে আপনার
                                        কারখানায় BNBC 2006, BNBC 2020 এবং NFPA 14 স্ট্যান্ডার্ড অনুযায়ী ফায়ার হাইড্রেন্ট সিস্টেম স্থাপন
                                        করুন।</p>
                                </details>
                            </div>
                        </div>


                    </div>
                </div> <!-- /.row -->


            </div> <!-- /.container -->

        <?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- /.container -->

        </div> <!-- /.pt-tablecell -->
    </div> <!-- /.pt-table -->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Development\dife\dife\resources\views/fire_safety/questions.blade.php ENDPATH**/ ?>