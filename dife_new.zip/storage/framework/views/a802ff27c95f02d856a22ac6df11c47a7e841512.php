<nav class="page-nav clear">
    <div class="container">
        <div class="flex flex-middle space-between">
            <span class="prev-page"><a href="#" class="link"></a></span>
            <span class="copyright hidden-xs">Copyright &copy; <?php echo e(date('Y')); ?> DIFE, All Rights Reserved.</span>
            <span class="next-page"><a href="#" class="link"></a></span>
        </div>
    </div>
    <!-- /.page-nav -->
</nav>
<!-- /.container --><?php /**PATH D:\Development\dife\dife\resources\views/footer.blade.php ENDPATH**/ ?>