<nav class="page-nav clear">
    <div class="container">
        <div class="flex flex-middle space-between">
            <span class="prev-page"><a href="#" class="link"></a></span>
            <span class="copyright hidden-xs">Copyright &copy; {{date('Y')}} DIFE, All Rights Reserved.</span>
            <span class="next-page"><a href="#" class="link"></a></span>
        </div>
    </div>
    <!-- /.page-nav -->
</nav>
<!-- /.container -->